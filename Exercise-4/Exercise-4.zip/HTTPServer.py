from socket import * 
import sys 

serverSocket = socket(AF_INET, SOCK_STREAM)
serverPort = 6789
serverAddr = '...............'

# Bind the socket to server address and server port, then listen
serverSocket.bind((serverAddr, serverPort))
serverSocket.listen(1)


while True:
	print('The server is ready to receive')

	# Set up a new connection from the client
	connectionSocket............................

	# Receives the request message from the client
	message = ...................................  #should have .decode()
	# Extract the path of the requested object from the message
	# The path is the second part of HTTP header, identified by [1]
	filename = message.split()[1]
	f = open(filename[1:])
	outputdata = f.read() 	# Store the file in a temporary buffer
	# Send the HTTP response header line to the connection socket
	............................................  # don't need .encode() here 
 
	# Send the content of the requested file to the connection socket
	for i in range(0, len(outputdata)):  
		...................... # each time send outputdata[i]

	connectionSocket.send("\r\n") 
	connectionSocket.close()


serverSocket.close()  
sys.exit()#Terminate the program after sending the corresponding data
